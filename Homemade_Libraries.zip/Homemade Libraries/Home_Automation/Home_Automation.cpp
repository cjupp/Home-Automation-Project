/*--------------------------------------------------------------------------------------------------------------------
| Home_Automation.cpp: Organizes and houses all global objects and libraries needed for home automation and heating 
|
| Created by:     Cameron Jupp
| Date Started:   January 7, 2023
--------------------------------------------------------------------------------------------------------------------*/ 
#include "Home_Automation.h"

#include <Arduino.h>

#include <WiFi.h>
#include "time.h"
#include "sntp.h"

#include <Wire.h>

#include "Arduino.h"

#include "Active_WiFi.h"
#include "Analog_Stick.h"
#include "EEPROM_Manager.h"
#include "Events_Scheduling.h"
#include "HTTP_Server.h"
#include "OLED_Tools.h"
#include "OLED_HMI.h"
#include "Serial_Tools.h"
#include "Simple_Menu.h"
#include "Real_Timekeeping.h"


// -------------------------------------------------------------------------------------------------------------------- //
// -------------------------- / ___/  / /     / __  /  / _ /    / _\      / /     / ____/ ----------------------------- //
// ------------------------- / /_//  / /__   / /_/ /  / _  \   / /_\\    / /__    \__ \  ------------------------------ //
// ------------------------ /____/  /____/  /_____/  /_____/  /_/   \\  /____/  /_____/ ------------------------------- //
// -------------------------------------------------------------------------------------------------------------------- //

int eepromWifiIndex = 0;

int eepromHeatingIndex = 0;

char nameBuff[40];
char passBuff[40];

// Declare the analog stick used for the project using the defined pins and threshold
analogStick joystick;

// Declare the menu frame object for the main menu
menuFrame mainMenu;

// Declare the event handler for the heating
eventHandler heatEvents;


// -------------------------------------------------------------------------------------------------------------------- //
// ----------------------------- / ___/  / /     / _\      / ____/  / ____/  / ___/  / ____/ -------------------------- //
// ---------------------------- / /__   / /__   / /_\\     \__ \    \__ \   / __/    \__ \  --------------------------- //
// --------------------------- /____/  /____/  /_/   \\  /_____/  /_____/  /____/  /_____/ ---------------------------- //
// -------------------------------------------------------------------------------------------------------------------- //



// -------------------------------------------------------------------------------------------------------------------- //
// -------------------  / ___/  / / //  / \  / /  / ___/ /__  __/  /_  _/  / __  /  / \  / /  / ____/ ----------------- //
// ------------------  / __/   / /_//  / /\\/ /  / /__     / /      / /   / /_/ /  / /\\/ /   \__ \ ------------------- //
// -----------------  /_/     /____/  /_/  \_/  /____/    /_/     /___/  /_____/  /_/  \_/  /_____/ ------------------- //
// -------------------------------------------------------------------------------------------------------------------- //

char HA_SystemInit()
{
  char returnVal;
  Serial.begin(115200);

  // Initialize and clear the OLED display
  oledSystemInit();

  // Menu initializations
  initMenu();


  oledDisplay.clearDisplay();
  oledDisplay.setTextColor(WHITE);
  oledDisplay.setCursor(0,0);
  oledDisplay.setTextSize(2);

  oledDisplay.write("Starting");

  oledDisplay.display();

  delay(2000);
  
  oledDisplay.clearDisplay();

  oledDisplay.display();
  
  //Load EEPROM - EEPROM system init?
  eepromPointersInit();
  loadObjects();

  //Ready timekeeping
  timeSystemInit();

  //Check to see if the first wifi network is configured
  if(network_list[0].status == CONFIGURED)
  {
    //Attempt to connect to first wifi network
    returnVal = network_list[0].connect()

    if(!returnVal)
    {
      //If successful, start system and get NTP

    }
  }

  //If fails connection, or if there is no configuration, ask user for wifi
  else if(network_list[0].status == UNCONFIGURED || returnVal)
  {
    
    if(askWiFi() == 1)
    {

      searchWiFi(&mainMenu, WIFI_MENU);
    }
    else
    {
      manSetTime();
    }
    
  }


}

void startSystemThreads()
{
  //Start wifi check thread

  //Start schedule check thread

  //Start time updating thread

  //Start HTTP server thread

  //Start main menu thread
}










char askWiFi()
{
  // create yes/no prompt in OLED_HMI library
  return getYN("Would you like to connect to WiFI?");
}

void manSetTime()
{
  // get time with heading "Set Time"

  // set internal clock
  
}

void initMenu()
{
  //Main menu
  mainMenu.addMenu("Main Menu", MAIN_MENU);

  //Heating node
  mainMenu.addNode("Heating", SUB_NODE, NULL);
  mainMenu.linkNode(HEAT_MENU);

  //WiFi node
  mainMenu.addNode("WiFi", SUB_NODE, NULL);
  mainMenu.linkNode(WIFI_MENU);

  //Time node
  mainMenu.addNode("Time", SUB_NODE, NULL);
  mainMenu.linkNode(TIME_MENU);


  // Heating menu and nodes
  mainMenu.addMenu("Heating", HEAT_MENU);
  
  mainMenu.addNode("Add", ACT_NODE, &addSchedule);

  mainMenu.addNode("Delete", SUB_NODE, NULL);
  mainMenu.linkNode(DEL_HEAT_MENU);

  mainMenu.addNode("View", SUB_NODE, NULL);
  mainMenu.linkNode(VIEW_HEAT_MENU);
  

  //WiFi menu and nodes
  mainMenu.addMenu("WiFi", WIFI_MENU);

  mainMenu.addNode("Scan WiFi", ACT_NODE, NULL);

  mainMenu.addNode("Disconnect", ACT_NODE, NULL);

  mainMenu.addNode("Reconnect", ACT_NODE, NULL);


  //Time menu and nodes
  mainMenu.addMenu("Time", TIME_MENU);

  mainMenu.addNode("Set Time", ACT_NODE, NULL);

  mainMenu.addNode("Get NTP", ACT_NODE, NULL);
  

  //View Schedules menu
  mainMenu.addMenu("View", VIEW_HEAT_MENU);
  //Menu nodes added by other function


  //Delete Schedules menu
  mainMenu.addMenu("Delete", DEL_HEAT_MENU);
  //Menu nodes added by other function


  //Menu for displaying access points
  mainMenu.addMenu("APs", NETWORK_MENU);

}











void eepromPointersInit()
{
  char index = 0;

  eepromWifiIndex = index;

  index += sizeof(WAP);

  eepromHeatingIndex = index;

}


void loadObjects()
{
  //Load in wifi configuration
  loadConfig(eepromWifiIndex, 0, sizeof(network_list[0]), network_list[0]);

  //Load in heating schedules
  for(int i = 0; i < MAX_EVENTS; i++)
  {
    return loadConfig(eepromHeatingIndex, i, sizeof(heatEvents[i]), heatEvents[i]);
  }
}

void saveWiFi(WAP * wifi, char startIndex)
[
  saveConfig(startIndex, i, sizeof(*wifi), (char*)wifi);
]

void saveSchedules(eventHandler * scheds, char startIndex)
{
  for(int i = 0; i < MAX_EVENTS; i++)
  {
    saveConfig(startIndex, i, sizeof(*scheds), (char*)scheds);
  }
}


char loadConfig(char start, char index, char size, char * ptr)
{
  char startIndx = start + (index*size);
  return writeEEPROM(ptr, size, startIndx) ?  -1 : 0;
}

char saveConfig(char start, char index, char size, char * ptr)
{
  char startIndx = start + (index*size);
  return readEEPROM(ptr, size, startIndx) ?  -1 : 0;
}

char setTime()
{
  
}


