void searchWifi(menuFrame * menu, char menuIndex)
{
  int netNum = 0;

  menu->menuList[menuIndex].resetNodes();
  
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  netNum = WiFi.scanNetworks();

  for(int i = 0; i < netNum; i++)
  {
    Serial.println(WiFi.SSID(i));
    WiFi.SSID(i).toCharArray(nameBuff, WiFi.SSID(i).length()+1);
    menu->manAddNode(nameBuff, menuIndex, ACT_NODE, &connectWiFi);
  }

  menu->currentMenu = menuIndex;
}

connectWiFi()
{
  getStr(passBuff);
  WiFi.SSID(wifiList.nodeIndex).toCharArray(nameBuff, WiFi.SSID(wifiList.nodeIndex).length()+1);
  Serial.println(nameBuff);
  Serial.println(passBuff);
  
  oledDisplay.clearDisplay();
  oledDisplay.setTextColor(WHITE); // Draw white text
  oledDisplay.setCursor(0, 0);     // Start at top-left corner
  
  oledDisplay.printf("Connecting to\n%s", nameBuff);
  oledDisplay.display();
  
  WiFi.begin(nameBuff, passBuff);

  char timeout = 0;

  while (WiFi.status() != WL_CONNECTED && timeout++ < 16) 
  {
    vTaskDelay(500 / portTICK_PERIOD_MS);
  }

  if(WiFi.status() == WL_CONNECTED)
  {
    //Save config in wap list

    //display message

    //return 0

  }
  else
  {
    //display message

    //return -1


  }


  Serial.println("Connected!");
}

void checkHeatTask(void * parameters)
{
  for(;;)
  {
    checkSched(&heatEvents);
    vTaskDelay(30000 / portTICK_PERIOD_MS);
  }
}

void checkSched(eventHandler * schedules)
{
  Serial.println("Checking Events...");
  Serial.println(esp32Time.tm_hour, DEC);
  Serial.println(esp32Time.tm_min, DEC);
  schedules->check(esp32Time.tm_hour, esp32Time.tm_min, 0b00010000);
}

void menuThread(void * parameters)
{
  for(;;)
  {
      menuLoop(&mainMenu, &joystick);
      vTaskDelay(MAIN_MENU_DELAY / portTICK_PERIOD_MS);
  }
}

void menuLoop(menuFrame * menu, analogStick * stick)
{
  menu->build();
  stick->update();
   if(!stick->held.x)
   {
     switch (stick->status.x)
     {
      case 'l':
      menu->back();
      break;
  
      case 'r':
      menu->choose();
      break;
     }
   }
   if(!stick->held.y)
   {
     switch (stick->status.y)
     {
      case 'u':
      menu->up();
      break;
  
      case 'd':
      menu->down();
      break;
     }
   }
   if(!stick->held.button && stick->status.button)
   {
      menu->choose();
   }
}

char getStr(char * string)
{
  strInput strMenu;
  //strMenu.reset();
  char continuous = 0;
  char returnVal;
  
  do
  {
   strMenu.build();
   joystick.update();
   if(!joystick.held.x || continuous)
   {
     switch (joystick.status.x)
     {
      case 'l':
      strMenu.move('l');
      break;
  
      case 'r':
      strMenu.move('r');
      break;
     }
   }
   if(!joystick.held.y || continuous)
   {
     switch (joystick.status.y)
     {
      case 'u':
      strMenu.move('u');
      break;
  
      case 'd':
      strMenu.move('d');
      break;
     }
   }
   if(!joystick.held.button && joystick.status.button)
   {
      strMenu.sel();
   }

   delay(100);
  }while(!strMenu.complete);

  if(strMenu.complete == 1)
  {
    strcpy(string, strMenu.output);
    
    Serial.print("Name: ");
    Serial.println(strMenu.output);
  }
  else
  {
    Serial.println("Canceled");

  }
  return strMenu.complete;
}

 char getTime(clkTime * newTime, char * header)
{
  timeInput timeMenu;
  timeMenu.setHeader(header);
  
  timeMenu.reset();
  char returnVal;
  do
  {
    timeMenu.build();
    joystick.update();
   if(!joystick.held.x)
   {
     switch (joystick.status.x)
     {
      case 'l':
      timeMenu.left();
      break;
  
      case 'r':
      timeMenu.right();
      break;
     }
   }
   if(!joystick.held.y)
   {
     switch (joystick.status.y)
     {
      case 'u':
      timeMenu.up();
      break;
  
      case 'd':
      timeMenu.down();
      break;
     }
   }
   if(!joystick.held.button && joystick.status.button)
   {
      timeMenu.sel();
   }
   delay(100);
    
  }while(!timeMenu.complete);

  if(timeMenu.complete == 1)
  {
    Serial.print("Time: ");
    Serial.print(timeMenu.output[0], DEC);
    Serial.print(timeMenu.output[1], DEC);
    Serial.print(":");
    Serial.print(timeMenu.output[2], DEC);
    Serial.println(timeMenu.output[3], DEC);

    *newTime = *timeMenu.accept();
    
  }
  else
  {
    Serial.println("Canceled");
  }
   return timeMenu.complete;

}

char getWeek(char * weekdays)
{
  weekdayInput weekMenu;
  //weekMenu.reset();
  char returnVal;
  do
  {
    weekMenu.build();
    joystick.update();
    if(!joystick.held.x)
    {
     switch (joystick.status.x)
     {
      case 'l':
      weekMenu.left();
      break;
    
      case 'r':
      weekMenu.right();
      break;
     }
    }
    if(!joystick.held.button && joystick.status.button)
    {
      weekMenu.sel();
    }
   
    delay(100);
    
  }while(!weekMenu.complete);

  Serial.print("Week Returned: ");
  Serial.println(weekMenu.complete, DEC);

  if(weekMenu.complete == 1)
  {
    Serial.print("Weekdays: ");
    Serial.println(weekMenu.days, BIN);
    *weekdays = weekMenu.days;
  }
  else
  {
    Serial.println("Canceled");
  }  
  return weekMenu.complete;
}



char getYN(char * msg)
{
  yesNoInput ynMenu;
  ynMenu.setMsg(msg);
  
  char returnVal;
  do
  {
    ynMenu.build();
    joystick.update();
    if(!joystick.held.x)
    {
     switch (joystick.status.x)
     {
      case 'l':
      ynMenu.left();
      break;
    
      case 'r':
      ynMenu.right();
      break;
     }
    }
    if(!joystick.held.button && joystick.status.button)
    {
      returnVal = ynMenu.sel();
    }
   
    delay(100);
    
  }while(!returnVal);

  Serial.print("Answer: ");
  
  if(ynMenu.complete == 1)
  {

    Serial.println("Yes/OK");
  }
  else
  {
    Serial.println("No/Cancel");
  }  
  return ynMenu.complete;
}



void testFunct(char param)
{
  if(param)
  {
    Serial.println("Schedule activated");
  }
  else
  {
    Serial.println("Schedule deactivated");
  }
 
}

void updateTime(void * parameters)
{

  for(;;)
  {
    getLocalTime(&esp32Time);
    

    vTaskDelay(500 / portTICK_PERIOD_MS);
  }

}


void addSchedule(eventHandler * sched, menuFrame * menu, char viewIndex, char delIndex)
{
  clkTime strtTime, endTime;
  char strBuffer[OLED_INPUT_CHARS];
  char weekdays = 0;
  signed char returnVal;
  
  char i = 0;
  do
  {
    switch(i)
    {
      case 0:
        //get start time
        returnVal = getTime(&strtTime, "Start Time");
      break;

      case 1:
        //get end time
        returnVal = getTime(&endTime, "End Time");
      break;

      case 2:
        returnVal = getStr(strBuffer);
      break;

      case 3:
        returnVal = getWeek(&weekdays);
      break;
    }
    Serial.print("Returned: ");
    Serial.println(returnVal, DEC);
  }while(returnVal!= -1 && i++ < 4);

  oledDisplay.clearDisplay();
  oledDisplay.setTextColor(WHITE);
  oledDisplay.setCursor(0,0);
  oledDisplay.setTextSize(2);
  
  if(returnVal == 1)
  {
    // Add the event to the eventHandler
    sched->addEvent(strBuffer, strtTime, endTime, weekdays, &testFunct);
    
    // Add the node to the menu to be viewed
    menu->manAddNode(sched->events[sched->numConfigd-1].name, viewIndex, ACT_NODE, &viewSched);

    // Add the node to the delete menu
    menu->manAddNode(sched->events[sched->numConfigd-1].name, delIndex, ACT_NODE, &delSched);
    
    oledDisplay.write(" Schedule\n  Added");
  }
  else
  {
    oledDisplay.write(" Canceled");
  }
  
  oledDisplay.display();

  // Allow time for message to be read
  vTaskDelay(2000 / portTICK_PERIOD_MS);
  // Reset analog stick state
  joystick.update();
}

void viewSched(eventHandler * sched, menuFrame * menu)
{
  oledDisplay.clearDisplay();
  oledDisplay.setTextColor(WHITE);
  oledDisplay.setCursor(0,0);
  
  
  char schedIndex = menu->nodeIndex;

  Serial.println(sched->events[schedIndex].name);
  Serial.println(sched->events[schedIndex].startTime.hr, DEC);
  Serial.println(sched->events[schedIndex].startTime.min, DEC);
  Serial.println(sched->events[schedIndex].endTime.hr, DEC);
  Serial.println(sched->events[schedIndex].endTime.min, DEC);

  oledDisplay.setTextSize(2);
  oledDisplay.printf("%s\n", sched->events[schedIndex].name);

  oledDisplay.setTextSize(1);
  oledDisplay.printf("Start:\n%u:%u\n", sched->events[schedIndex].startTime.hr, sched->events[schedIndex].startTime.min);

  oledDisplay.printf("End:\n%u:%u\n", sched->events[schedIndex].endTime.hr, sched->events[schedIndex].endTime.min);

  char days[25];
  char daysIndex = 0;

  for(int i = 0; i < 8; i++)
  {
    if(BIT0<<i & sched->events[schedIndex].weekDays)
    {
      days[daysIndex++] = hmiWeekdays[i][0];
      days[daysIndex++] = hmiWeekdays[i][1];
      days[daysIndex++] = ' ';   
    }
  }
  days[daysIndex] = '\0';

  oledDisplay.printf("Days:\n%s\n", days);

  oledDisplay.display();
  vTaskDelay(5000 / portTICK_PERIOD_MS);
}

void delSched()
{
  //create delete method in Simple Menu

  //remove menu item based on menu index

  //delete schedule from array
}


void startCheck()
{
  // Load in saved wifi network(s) and schedules
  // If there is a valid wifi connection saved, attempt to connect to it
  // If there is no valid network, prompt the user if they want to add a network
  
  // If the connection fails, prompt user to choose if they want to add a new network
  // If they choose no, then prompt for the time
}