

#include "LCD_Tools.h"



void lcdSystemInit()
{

}
